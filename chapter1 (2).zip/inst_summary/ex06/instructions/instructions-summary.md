### Summary
From 1925 through 1963, Burma Shave advertising signs appeared next to highways all across the United States. There were always four or five signs in a row containing pieces of a rhyme, followed by a final sign that read “Burma Shave.” For example, one set of signs that has been preserved by the Smithsonian Institution reads as follows:


_Shaving brushes  
You’ll soon see ’em  
On a shelf  
In some museum  
Burma Shave_

### Instructions
Find a classic Burma Shave rhyme on the Web and write a program named
_BurmaShave_ that displays the rhyme.


