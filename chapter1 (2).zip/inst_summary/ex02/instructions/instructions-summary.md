Write, compile, and test a program named **Lyrics** that displays at least four lines of your favorite song.


