Write a program named _Comments_ that displays a statement that defines program comments. Include at least one block comment, one line comment, and one `WriteLine()` statement in the program.


