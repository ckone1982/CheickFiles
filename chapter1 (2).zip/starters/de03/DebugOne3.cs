using static System.Console;
classs DebugOne3
{
   static void Mane()
   {
      WriteLine("This program lists the number 1 to 5 vertically");
      Write("1");
      Write("2");
      Write("3");
      Write("4");
      Write("5");
   }
}
