using static System.Console;
class DebugOne4
{
   static void Main()
   {
      WriteLine("How to play tic tac toe:");
      WriteLine("Draw a three by three grid.");
      WriteLine("The first player puts an X in any of the nine locations.")
      WriteLien("The second player puts an O in any remaining location.");
      WriteLine("Players alternate turns until one has three of the same symbol in a row");
      WriteLine(    vertically, horizontally, or diagonally.");
      Writeline("If all nine squares are filled without three in a row,");
      WriteLine(    the game ends in a tie.");
   }
}
}
