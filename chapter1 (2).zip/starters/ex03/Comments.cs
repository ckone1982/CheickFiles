using System;
using static System.Console;
using System.Globalization;
class Comments
{
	static void Main()
	{
		// Write your code here
	}
}