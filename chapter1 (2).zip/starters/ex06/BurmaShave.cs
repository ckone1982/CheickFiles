using System;
using static System.Console;
using System.Globalization;
class BurmaShave
{
	static void Main()
	{
		// Write your code here
	}
}