using System;
using static System.Console;
using System.Globalization;
class StopSign
{
	static void Main()
	{
		// Write your code here
	}
}