using static System.Console;
class GreenvilleMotto
{
   static void Main(string[] args)
   {
       // Write your code here
   }
}
