using static System.Console;
class DebugOne1
{
   static void Main()
   {
      Writeline("This program displays some keyboard punctuation");
      WriteLine("!   exclamation point");
      WriteLine("@   at-sign")
      WriteLine(("#   pound sign or hash mark");
      WriteLine("$   dollar sign);
   }
}

