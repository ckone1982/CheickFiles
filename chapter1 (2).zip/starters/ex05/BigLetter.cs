using System;
using static System.Console;
using System.Globalization;
class BigLetter
{
	static void Main()
	{
		// Write your code here
	}
}