using System;
using static System.Console;
using System.Globalization;
class PersonalInfo
{
	static void Main()
	{
		// Write your code here
	}
}
