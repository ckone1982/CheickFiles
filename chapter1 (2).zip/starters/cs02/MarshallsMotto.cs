using static System.Console;
class MarshallsMotto
{
   static void Main(string[] args)
   {
       // Write your code here
   }
}
